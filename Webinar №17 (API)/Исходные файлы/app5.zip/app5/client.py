import asyncio
import websockets

async def chat():
    uri = 'ws://localhost:8765'
    async with websockets.connect(uri) as websocket:
        name = input("Enter your name: ")
        print("Type 'exit' to quit")
        while True:
            message = input(f"{name}: ")
            if message.lower() == 'exit':
                break
            await websocket.send(f"{name}: {message}")
            # Получение сообщений
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=1)
                print(response)
            except asyncio.TimeoutError:
                pass

if __name__ == '__main__':
    asyncio.run(chat())
