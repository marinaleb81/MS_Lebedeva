import asyncio
import websockets

connected_clients = set()

async def handler(websocket, path):
    connected_clients.add(websocket)
    try:
        async for message in websocket:
            # Рассылка сообщения всем подключенным клиентам
            for client in connected_clients:
                if client != websocket:
                    await client.send(message)
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        connected_clients.remove(websocket)

async def main():
    async with websockets.serve(handler, 'localhost', 8765):
        print("WebSocket server is running on ws://localhost:8765")
        await asyncio.Future()  # Бесконечная задача

if __name__ == '__main__':
    asyncio.run(main())
