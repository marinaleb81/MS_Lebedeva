from spyne import Application, rpc, ServiceBase, Integer, Unicode
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication

class ItemService(ServiceBase):
    @rpc(Integer, _returns=Unicode)
    def get_item(self, item_id):
        items = {
            1: 'Item One',
            2: 'Item Two'
        }
        return items.get(item_id, 'Item not found')

application = Application([ItemService], 'spyne.examples.hello.soap',
                          in_protocol=Soap11(validator='lxml'),
                          out_protocol=Soap11())

if __name__ == '__main__':
    from wsgiref.simple_server import make_server

    server = make_server('localhost', 8000, WsgiApplication(application))
    print("Listening on http://localhost:8000")
    print("WSDL is available at: http://localhost:8000/?wsdl")
    server.serve_forever()

