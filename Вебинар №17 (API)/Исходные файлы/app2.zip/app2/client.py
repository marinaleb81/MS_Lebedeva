from zeep import Client

wsdl = 'http://localhost:8000/?wsdl'
client = Client(wsdl=wsdl)

response = client.service.get_item(2)
print(f"Response: {response}")
